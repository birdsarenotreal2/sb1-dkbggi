import { HttpError } from 'wasp/server'

export const getTrips = async (args, context) => {
  if (!context.user) { throw new HttpError(401) }

  return context.entities.Trip.findMany({
    where: {
      userId: context.user.id
    }
  });
}

export const calculateRoute = async (args, context) => {
  if (!context.user) { throw new HttpError(401) }

  // Assume args contain startLocation, endLocation, waypoints, preferredArrivalTime, and preferredDepartureTime
  const { startLocation, endLocation, waypoints, preferredArrivalTime, preferredDepartureTime } = args;

  // Logic to calculate the most efficient route considering real-time traffic data
  // Mocking the calculation and returning dummy data for now
  const estimatedCost = 100.0; // Dummy cost
  const estimatedTime = 90; // Dummy time in minutes

  return {
    route: {
      startLocation,
      endLocation,
      waypoints,
      estimatedCost,
      estimatedTime
    }
  };
}
