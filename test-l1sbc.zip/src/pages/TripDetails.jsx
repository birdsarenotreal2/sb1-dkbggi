import React from 'react';
import { useParams } from 'wasp/client/router';
import { useQuery, useAction, calculateRoute, updateTripStatus, getTrips } from 'wasp/client/operations';

const TripDetailsPage = () => {
  const { tripId } = useParams();
  const { data: trips, isLoading: isTripsLoading, error: tripsError } = useQuery(getTrips);
  const updateTripStatusFn = useAction(updateTripStatus);
  const { data: routeData, isLoading: isRouteLoading, error: routeError } = useQuery(calculateRoute, {
    variables: { tripId }
  });

  const handleUpdateStatus = (newStatus) => {
    updateTripStatusFn({ tripId, newStatus });
  };

  if (isTripsLoading || isRouteLoading) return 'Loading...';
  if (tripsError || routeError) return `Error: ${tripsError || routeError}`;

  const trip = trips.find(t => t.id === parseInt(tripId));
  const { startLocation, endLocation, waypoints, estimatedCost, estimatedTime } = routeData.route;

  return (
    <div className='p-6 bg-gray-900 text-white rounded-lg'>
      <h2 className='text-2xl font-bold mb-4'>Trip Details</h2>
      <div className='mb-4'>
        <p><strong>Start Location:</strong> {startLocation}</p>
        <p><strong>End Location:</strong> {endLocation}</p>
        <p><strong>Waypoints:</strong> {waypoints}</p>
        <p><strong>Estimated Cost:</strong> ${estimatedCost.toFixed(2)}</p>
        <p><strong>Estimated Time:</strong> {estimatedTime} minutes</p>
      </div>
      <div className='flex gap-4'>
        <button
          onClick={() => handleUpdateStatus('confirmed')}
          className='bg-green-500 hover:bg-green-700 text-white font-bold py-2 px-4 rounded'
        >
          Confirm
        </button>
        <button
          onClick={() => handleUpdateStatus('cancelled')}
          className='bg-red-500 hover:bg-red-700 text-white font-bold py-2 px-4 rounded'
        >
          Cancel
        </button>
        <button
          onClick={() => handleUpdateStatus('pending')}
          className='bg-yellow-500 hover:bg-yellow-700 text-white font-bold py-2 px-4 rounded'
        >
          Modify
        </button>
      </div>
    </div>
  );
};

export default TripDetailsPage;
