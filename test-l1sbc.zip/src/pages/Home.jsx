import React, { useState } from 'react';
import { useQuery, useAction } from 'wasp/client/operations';
import { getTrips, createTrip } from 'wasp/client/operations';
import { Link } from 'wasp/client/router';

const HomePage = () => {
  const { data: trips, isLoading, error } = useQuery(getTrips);
  const createTripFn = useAction(createTrip);
  const [newTrip, setNewTrip] = useState({
    startLocation: '',
    endLocation: '',
    waypoints: '',
    preferredArrivalTime: '',
    preferredDepartureTime: ''
  });

  if (isLoading) return 'Loading...';
  if (error) return 'Error: ' + error;

  const handleCreateTrip = () => {
    createTripFn(newTrip);
    setNewTrip({
      startLocation: '',
      endLocation: '',
      waypoints: '',
      preferredArrivalTime: '',
      preferredDepartureTime: ''
    });
  };

  return (
    <div className="p-4 bg-gray-900 text-white rounded-lg">
      <h1 className="text-2xl font-bold mb-4">My Trips</h1>
      <div className="mb-4">
        <input
          type="text"
          placeholder="Start Location"
          value={newTrip.startLocation}
          onChange={(e) => setNewTrip({ ...newTrip, startLocation: e.target.value })}
          className="bg-gray-800 text-white p-2 rounded mb-2 w-full"
        />
        <input
          type="text"
          placeholder="End Location"
          value={newTrip.endLocation}
          onChange={(e) => setNewTrip({ ...newTrip, endLocation: e.target.value })}
          className="bg-gray-800 text-white p-2 rounded mb-2 w-full"
        />
        <input
          type="text"
          placeholder="Waypoints"
          value={newTrip.waypoints}
          onChange={(e) => setNewTrip({ ...newTrip, waypoints: e.target.value })}
          className="bg-gray-800 text-white p-2 rounded mb-2 w-full"
        />
        <input
          type="datetime-local"
          placeholder="Preferred Arrival Time"
          value={newTrip.preferredArrivalTime}
          onChange={(e) => setNewTrip({ ...newTrip, preferredArrivalTime: e.target.value })}
          className="bg-gray-800 text-white p-2 rounded mb-2 w-full"
        />
        <input
          type="datetime-local"
          placeholder="Preferred Departure Time"
          value={newTrip.preferredDepartureTime}
          onChange={(e) => setNewTrip({ ...newTrip, preferredDepartureTime: e.target.value })}
          className="bg-gray-800 text-white p-2 rounded mb-2 w-full"
        />
        <button
          onClick={handleCreateTrip}
          className="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded w-full"
        >
          Create Trip
        </button>
      </div>
      <div>
        {trips.map((trip) => (
          <div key={trip.id} className="bg-gray-800 p-4 rounded-lg mb-2">
            <p><strong>From:</strong> {trip.startLocation}</p>
            <p><strong>To:</strong> {trip.endLocation}</p>
            <p><strong>Status:</strong> {trip.status}</p>
            <Link to={`/trip/${trip.id}`} className="text-blue-400 hover:underline">
              View Details
            </Link>
          </div>
        ))}
      </div>
    </div>
  );
};

export default HomePage;
