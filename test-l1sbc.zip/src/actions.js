import { HttpError } from 'wasp/server'

export const createTrip = async (args, context) => {
  if (!context.user) { throw new HttpError(401) };

  const newTrip = await context.entities.Trip.create({
    data: {
      userId: context.user.id,
      startLocation: args.startLocation,
      endLocation: args.endLocation,
      waypoints: args.waypoints,
      preferredArrivalTime: args.preferredArrivalTime,
      preferredDepartureTime: args.preferredDepartureTime,
      estimatedCost: args.estimatedCost,
      estimatedTime: args.estimatedTime,
      status: "pending"
    }
  });

  return newTrip;
}

export const updateTripStatus = async ({ tripId, newStatus }, context) => {
  if (!context.user) { throw new HttpError(401) };

  const trip = await context.entities.Trip.findUnique({
    where: { id: tripId },
    select: { userId: true }
  });
  if (trip.userId !== context.user.id) { throw new HttpError(403) };

  const validStatuses = ['confirmed', 'cancelled', 'completed'];
  if (!validStatuses.includes(newStatus)) { throw new HttpError(400, 'Invalid status') };

  return context.entities.Trip.update({
    where: { id: tripId },
    data: { status: newStatus }
  });
}
